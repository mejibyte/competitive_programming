source-highlight -i $1.java -o $1.tex -s java -f latexcolor

