source-highlight -i $1.cpp -o $1.tex -s cpp -f latexcolor

