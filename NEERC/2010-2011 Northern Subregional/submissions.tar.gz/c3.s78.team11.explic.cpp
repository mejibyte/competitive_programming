#include <iostream>
#include <cmath>
#include <algorithm>

using namespace std;

int facto [20];

int main () {
	int a;
	facto[0] = 1;
	for (int i = 1; i < 20; ++i)
		facto[i] = facto[i-1]*i;
	while(cin>>a){
		int tot = !!a;
		for (int i = 1; i < 10; ++i) {
			cin>>a;
			tot += a;
		}
		
		int res = 0;
		for (int i = 9; i >= 10-tot; --i) {
			res += i;
		}
		if (tot > 8)
		tot = 8;
		for (int i = 9; i >= 10-tot+1; --i) {
			res += facto[i]/(2*facto[i-2]);
		}
		cout<<!!(res&1)<<endl;
     }
}
