/*--------------------------------------------------------------*/
/* ACM ICPC 2010-2011, NEERC                                    */
/* Northern Subregional Contest                                 */
/* St Petersburg, October 30, 2010                              */
/*--------------------------------------------------------------*/
/* Problem A. Alien Communication Masterclass                   */
/*                                                              */
/* Original idea         Mikhail Dvorkin                        */
/* Problem statement     Mikhail Dvorkin                        */
/* Testset               Mikhail Dvorkin                        */
/*--------------------------------------------------------------*/
/* Solution                                                     */
/*                                                              */
/* Author                Maxim Buzdalov                         */
/*--------------------------------------------------------------*/
 
import java.io.*;
import java.util.*;

public class acm_mb {
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(System.in);
        PrintWriter out = new PrintWriter(System.out);

        int nPos = in.nextInt();
        in.nextInt();
        for (int i = 0; i < nPos; i++) {
            out.print("(10-1");
            for (int j = in.nextInt() - 1; j >= 1; --j) {
                out.print("-1");
            }
            out.print(")*");
        }
        out.println("1=0");
        in.close();
        out.close();
    }
}
