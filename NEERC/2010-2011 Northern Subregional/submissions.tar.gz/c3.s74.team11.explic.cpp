#include <iostream>
#include <cmath>
#include <algorithm>

using namespace std;

int facto [20];

int main () {
	
	facto[0] = 1;
	for (int i = 1; i < 20; ++i)
		facto[i] = facto[i-1]*i;
	int arr[10];
	int tot = 0;
	for (int i = 0; i < 10; ++i) {
		cin>>arr[i];
		if (arr[i])
			++tot;
	}
	
	int res = 0;
	for (int i = 9; i >= 10-tot; --i) {
		res += i;
	}
	for (int i = 9; i >= 10-tot+2; --i) {
		res += facto[i]/(2*facto[i-2]);
	}
	cout<<!!(res&1)<<endl;
}
