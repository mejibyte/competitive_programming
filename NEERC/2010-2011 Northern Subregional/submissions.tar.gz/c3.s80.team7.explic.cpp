#include<cstdio>
#include<iostream>
#include<vector>
#include<cstdlib>
#include<algorithm>

using namespace std;
int main(){
	bool res,x[10];
	while(cin>>x[1]>>x[2]>>x[3]>>x[4]>>x[5]>>x[6]>>x[7]>>x[8]>>x[9]>>x[10]){
		for(int i=0;i<9;++i){
			for(int j=i;j<10;++j){
				res ^= x[i]||x[j];
			}
		}
		for(int i=0;i<8;++i){
			for(int j=i;j<9;++j){
				for(int k=j;k<10;++k){
					res ^= x[i]||x[j]||x[k];
				}
			}
		}
		cout << res << endl;
	}
}
