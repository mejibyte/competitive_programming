#include <iostream>
#include <cstdio>
#include <set>

using namespace std;

int main(){
    int t[10];
    for(int i=0;i<10;++i){
        cin >> t[i];
    }
    puts("1");
    return 0;
}
