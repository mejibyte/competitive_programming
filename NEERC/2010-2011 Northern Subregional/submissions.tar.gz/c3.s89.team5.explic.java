import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;


public class e 
{
	public static class Scanner
	{
		final BufferedReader br;
		StringTokenizer st;
		
		public Scanner()
		{
			br = new BufferedReader(new InputStreamReader(System.in));
		}
		
		public String next()
		{
			try
			{
				while(st == null || !st.hasMoreTokens())
				{
					try
					{
						st = new StringTokenizer(br.readLine());
					}
					catch (IOException e) 
					{
						throw(new RuntimeException());
					}
				}
				return st.nextToken();
			}
			catch(Exception e)
			{
				System.exit(0);
				return "";
			}
		}
		
		public int nextInt()
		{
			return Integer.parseInt(next());
		}
	}

	static int[] valores = new int[10];
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner();
		while(true)
		{
			for(int i = 0; i < 10; i++)
				valores[i] = sc.nextInt();
			if(valores[0] == -1)
				return;
			int cuenta = 0;
			for(int i = 0; i < 10; i++)
				for(int j = i + 1; j < 10; j++)
					if(valores[i] == 1 || valores[j] == 1)
						cuenta++;
			for(int i = 0; i < 10; i++)
				for(int j = i + 1; j < 10; j++)
					for(int k = j + 1; k < 10; k++)
						if(valores[i] == 1 || valores[j] == 1 || valores[k] == 1)
							cuenta++;
			System.out.println((cuenta & 1) + "");
		}
	}
}
