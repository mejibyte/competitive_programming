using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <string>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <list>
#include <map>
#include <set>

template <class T> string toStr(const T &x) {
       stringstream s;
       s << x;
       return s.str(); 
}

template <class T> int toInt (const T &x) {
    stringstream s;
    s << x;
    int r;
    s >> r;
    return r;  
}

const double EPS = 1e-9;

int main () {
    //freopen("horrible.in","r",stdin);
    int n;
    while(cin>>n && n) {
        if (n == 1) {
            cout<<"1\n1 0\n";  
        }  
        else {
            cout<<(2*(n-1))*(n-1)+2+n<<endl;
            cout<<"2 -1\n";
            for (int act = 1; act < n; ++act) {
                cout<<act<<" 0\n";
                int yes = 1, no = 1;
                for (int count = 1; count <= 2*(n-1); ++count) {
                    if (count&1) {
                        if (yes == act)
                        ++yes;
                        cout<<yes<<" "<<act<<endl;
                        ++yes; 
                    }
                    else {
                        if(no == act+1)
                        ++no;
                        cout<<no<<" "<<-(act+1)<<endl;
                        ++no; 
                    }
                }
            }
            cout<<n<<" 0\n1 "<<n<<endl;
        }
    }  
}
