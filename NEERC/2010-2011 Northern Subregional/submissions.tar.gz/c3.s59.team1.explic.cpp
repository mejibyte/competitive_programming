#include <iostream>
#include <cstdio>
#include <set>

using namespace std;

int main(){
    puts("0");
    return 0;
}
