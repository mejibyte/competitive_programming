import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.StringTokenizer;


public class I 
{
	static class Scanner
	{
		BufferedReader br;
		StringTokenizer st;
		
		public Scanner()
		{
	    	System.setOut(new PrintStream(new BufferedOutputStream(System.out), true));
			br = new BufferedReader(new InputStreamReader(System.in));
		}
		
		public String next()
		{
			while(st == null || !st.hasMoreTokens())
			{
				try { st = new StringTokenizer(br.readLine()); }
				catch(Exception e) { throw new RuntimeException(); }
			}
			return st.nextToken();
		}

		public int nextInt()
		{
			return Integer.parseInt(next());
		}
		
		public double nextDouble()
		{
			return Double.parseDouble(next());
		}
		
		public String nextLine()
		{
			st = null;
			try { return br.readLine(); }
			catch(Exception e) { throw new RuntimeException(); }
		}
		
		public boolean endLine()
		{
			try 
			{
				String next = br.readLine();
				while(next != null && next.trim().isEmpty())
					next = br.readLine();
				if(next == null)
					return true;
				st = new StringTokenizer(next);
				return !st.hasMoreTokens();
			}
			catch(Exception e) { throw new RuntimeException(); }
		}
	}

	static int nProblems;
	
	public static class Equipo
	{
		int rank;
		int nSolved;
		StringTokenizer s;
		boolean[] solved;
		
		public Equipo(StringTokenizer s)
		{
			this.s = s;
		}
		
		public void leer()
		{
			LinkedList <String> tokens = new LinkedList <String> ();
			while(s.hasMoreTokens())
				tokens.add(s.nextToken());
			rank = Integer.parseInt(tokens.pollLast());
			tokens.pollLast();
			nSolved = Integer.parseInt(tokens.pollLast());
			solved = new boolean[nProblems];
			for(int i = 0; i < nProblems; i++)
				solved[nProblems - i - 1] = tokens.pollLast().contains("+");
		}
	}
	public static void main(String[] args)
	{
		Scanner sc = new Scanner();
		LinkedList <String> strings = new LinkedList <String> ();
		while(true)
		{
			String s = sc.nextLine();
			if(s == null)
				break;
			strings.add(s);
		}
		ArrayList <Equipo> equipos = new ArrayList <Equipo> ();
		while(true)
		{
			String s = strings.pollLast();
			StringTokenizer st = new StringTokenizer(s);
			if(st.countTokens() == 1)
			{
				s = strings.pollLast();
				st = new StringTokenizer(s);
				nProblems = st.countTokens() - 4;
				break;
			}
			else
				equipos.add(new Equipo(st));
		}
		for(Equipo e : equipos)
			e.leer();
		double t = equipos.size();
		double p = nProblems;
		double v = 0;
		double o = 0;
		for(Equipo e : equipos)
			if(e.nSolved == 0)
				v += 1 / t;
			else if(e.nSolved == nProblems)
				o += 1 / t;
		double e = 0;
		for(int i = 0; i < equipos.size() - 1; i++)
		{
			Equipo a = equipos.get(i);
			Equipo b = equipos.get(i + 1);
			if(b.nSolved - a.nSolved > 1)
				e += (b.nSolved - a.nSolved - 1) / p;
		}
		double u = 0;
		boolean[] resueltos = new boolean[nProblems];
		for(Equipo equipo : equipos)
		{
			for(int i = 0; i < nProblems; i++)
				resueltos[i] |= equipo.solved[i];
		}
		for(int i = 0; i < nProblems; i++)
			if(!resueltos[i])
				u += 1 / p;
		double[] inst = new double[nProblems];
		for(int pro = 0; pro < nProblems; pro++)
		{
			int inicio = equipos.size();
			for(int i = 0; i < equipos.size(); i++)
			{
				if(equipos.get(i).solved[pro])
				{
					inicio = i;
					break;
				}
			}
			for(int i = inicio + 1; i < equipos.size(); i++)
			{
				if(equipos.get(i).rank < equipos.get(inicio).rank && !equipos.get(i).solved[pro])
					inst[pro] += 1 / t;
			}
		}
		System.out.println("Vainness = " + v);
		System.out.println("Oversimplification = " + o);
		System.out.println("Evenness = " + e);
		System.out.println("Unsolvability = " + u);
		double acumInst = 0;
		for(int i = 0; i < nProblems; i++)
		{
			System.out.println("Instability " + (i + 1) + " = " + inst[i]);
			acumInst += inst[i];
		}
		acumInst /= p;
		double n = 1.03 * v + 3.141 * o + 2.171 * e + 1.414 * u + acumInst;
		System.out.println("Negidealness = " + n);
	}
}
