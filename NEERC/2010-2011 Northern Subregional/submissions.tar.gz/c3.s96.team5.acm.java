import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class A {

	void solve() throws IOException {
		int n = nextInt();
		int m = nextInt();
		for (int i = 0; i < n; ++i) {
			int a = nextInt();
			if (i > 0) {
				out.print("*");
			}
			out.print("(10");
			for (int j = 0; j < a; ++j) {
				out.print("-1");
			}
			out.print(")");
		}
		out.print("=0");
	}

	final String filename = "acm";
	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;

	void run() throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		out = new PrintWriter(new OutputStreamWriter(System.out));
		solve();
		out.close();
	}

	String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null)
				return null;
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	long nextLong() throws IOException {
		return Long.parseLong(next());
	}

	public static void main(String[] args) throws IOException {
		new A().run();
	}
}