import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.StringTokenizer;

public class C {

	void solve() throws IOException {
		int n = nextInt();
		int[] p = new int[n];
		for (int i = 0; i < n; ++i) {
			p[i] = nextInt() - 1;
		}
		int[] min = new int[n + 1];
		Arrays.fill(min, n);
		int[] cycleLen = new int[n];
		Arrays.fill(cycleLen, -1);
		boolean[] col = new boolean[n];
		for (int i = 0; i < n; ++i) {
			if (col[i]) {
				continue;
			}
			cycleLen[i] = 0;
			for (int j = i; !col[j]; j = p[j]) {
				col[j] = true;
				cycleLen[i]++;
			}
			min[cycleLen[i]] = Math.min(min[cycleLen[i]], i);
		}
		for (int i = 1; i <= n; ++i) {
			for (int j = 2 * i; j <= n; j += i) {
				min[j] = Math.min(min[j], min[i]);
			}
		}
		int[] f = new int[n];
		Arrays.fill(f, -1);
		for (int i = 0; i < n; ++i) {
			if (cycleLen[i] != -1) {
				int u = i, v = min[cycleLen[i]];
				for (int it = 0; it < cycleLen[i]; ++it) {
					f[u] = v;
					u = p[u];
					v = p[v];
				}
			}
		}
//		System.err.println(Arrays.toString(cycleLen));
		if (!Arrays.equals(mul(p, f), mul(f, p))) {
			throw new AssertionError();
		}
		for (int i : f) {
			out.print(i + 1 + " ");
		}
		out.println();
		out.flush();
	}

	private int[] mul(int[] a, int[] b) {
		int[] c = new int[a.length];
		for (int i = 0; i < a.length; ++i) {
			c[i] = a[b[i]];
		}
		return c;
	}

	final String filename = "commuting";
	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;

	void run() throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		out = new PrintWriter(new OutputStreamWriter(System.out));
//		Random rnd = new Random(42);
//		while (rnd != null) {
//			int n = rnd.nextInt(10000) + 1;
//			StringBuilder sb = new StringBuilder();
//			sb.append(n + "\n");
//			ArrayList<Integer> a = new ArrayList<Integer>();
//			for (int i = 0; i < n; ++i) {
//				a.add(i + 1);
//			}
//			Collections.shuffle(a);
//			for (int i = 0; i < n; ++i) {
//				sb.append(a.get(i) + " ");
//			}
//			st = new StringTokenizer(sb.toString());
//			solve();
//			System.err.print(".");
//		}
		solve();
		out.close();
	}

	String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null)
				return null;
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	long nextLong() throws IOException {
		return Long.parseLong(next());
	}

	public static void main(String[] args) throws IOException {
		new C().run();
	}
}
