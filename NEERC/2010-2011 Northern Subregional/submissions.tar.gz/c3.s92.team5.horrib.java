import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class H {

	void solve() throws IOException {
		int n = nextInt();
		if (n == 1) {
			out.println(1);
			out.println(1 + " " + 0);
			return;
		}
		out.println(2 + n + 2 * (n - 1) * (n - 1));
		out.println("2 -1");
		for (int i = 1; i <= n; ++i) {
			out.println(i + " " + 0);
			if (i < n) {
				ArrayList<String> list1 = new ArrayList<String>();
				ArrayList<String> list2 = new ArrayList<String>();
				for (int j = 1; j <= n; ++j) {
					if (j != i) {
						list1.add(j + " " + i);
					}
					if (j != i + 1) {
						list2.add(j + " " + (-i - 1));
					}
				}
				if (list1.size() != n - 1 || list2.size() != n - 1) {
					throw new AssertionError();
				}
				for (int j = 0; j < n - 1; ++j) {
					out.println(list1.get(j));
					out.println(list2.get(j));
				}
			}
		}
		out.println(1 + " " + n);
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;

	void run() throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		out = new PrintWriter(new OutputStreamWriter(System.out));
		solve();
		out.flush();
		out.close();
	}

	String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null)
				return null;
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	long nextLong() throws IOException {
		return Long.parseLong(next());
	}

	public static void main(String[] args) throws IOException {
		new H().run();
	}
}
