#inclu

int main () {
	INT asf;
}
