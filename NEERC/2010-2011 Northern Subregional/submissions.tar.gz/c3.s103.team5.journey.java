import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.StringTokenizer;

public class J {
	private static final long INF = Long.MAX_VALUE / 10;
	int n, t;

	static class Edge {
		int to;
		long weight;

		public Edge(int to, long weight) {
			super();
			this.to = to;
			this.weight = weight;
		}

	}

	@SuppressWarnings("unchecked")
	void solve() throws IOException {
		n = nextInt();
		int s = nextInt() - 1;
		t = nextInt() - 1;

		int m1 = nextInt();
		ArrayList<Edge>[] a1 = new ArrayList[n];
		for (int i = 0; i < a1.length; i++) {
			a1[i] = new ArrayList<J.Edge>();
		}
		for (int i = 0; i < m1; i++) {
			int x = nextInt() - 1;
			int y = nextInt() - 1;
			int len = nextInt();
			a1[x].add(new Edge(y, len));
			a1[y].add(new Edge(x, len));
		}
		long[] dist1 = dijkstra(a1, t);

		int m2 = nextInt();
		ArrayList<Edge>[] a2 = new ArrayList[n];
		for (int i = 0; i < a2.length; i++) {
			a2[i] = new ArrayList<J.Edge>();
		}
		for (int i = 0; i < m2; i++) {
			int x = nextInt() - 1;
			int y = nextInt() - 1;
			int len = nextInt();
			a2[x].add(new Edge(y, len));
			a2[y].add(new Edge(x, len));
		}
		long[] dist2 = dijkstra(a2, t);

		a = new ArrayList[2 * n];
		for (int i = 0; i < a.length; i++) {
			a[i] = new ArrayList<J.Edge>();
		}
		for (int i = 0; i < n; i++) {
			for (Edge e : a1[i]) {
				if (dist1[e.to] < dist1[i]) {
					a[2 * i + 1].add(new Edge(2 * e.to, e.weight));
				}
			}
			for (Edge e : a2[i]) {
				if (dist2[e.to] < dist2[i]) {
					a[2 * i].add(new Edge(2 * e.to + 1, e.weight));
				}
			}

		}
		color = new int[2 * n];
		ans = new long[2 * n];
		out.println(dfs(2 * s + 1));
	}

	long dfs(int v) {
		if (v == 2 * t || v == 2 * t + 1) {
			color[v] = 2;
			return ans[v] = 0;
		}
		if (color[v] == 1) {
			out.println(-1);
			out.close();
			System.exit(0);
		}
		color[v] = 1;
		long best = -INF;
		for (Edge e : a[v]) {
			if (color[e.to] != 2) {
				dfs(e.to);
			}
			best = Math.max(best, e.weight + ans[e.to]);
		}
		color[v] = 2;
		return ans[v] = best;
	}

	ArrayList<Edge>[] a;
	int[] color;
	long[] ans;

	private long[] dijkstra(ArrayList<Edge>[] a, int t) {
		long[] dist = new long[n];
		Arrays.fill(dist, INF);
		dist[t] = 0;
		boolean[] u = new boolean[n];
		for (int i = 0; i < n; i++) {
			int best = -1;
			for (int j = 0; j < dist.length; j++) {
				if (!u[j] && (best == -1 || dist[j] < dist[best])) {
					best = j;
				}
			}
			u[best] = true;
			for (Edge e : a[best]) {
				dist[e.to] = Math.min(dist[e.to], dist[best] + e.weight);
			}
		}
		return dist;
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;

	void run() throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		out = new PrintWriter(new OutputStreamWriter(System.out));
		solve();
		out.flush();
		out.close();
	}

	String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null)
				return null;
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	long nextLong() throws IOException {
		return Long.parseLong(next());
	}

	public static void main(String[] args) throws IOException {
		new J().run();
	}
}
