import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;


public class k
{
	public static class Scanner
	{
		final BufferedReader br;
		StringTokenizer st;
		
		public Scanner()
		{
			br = new BufferedReader(new InputStreamReader(System.in));
		}
		
		public String next()
		{
			try
			{
				while(st == null || !st.hasMoreTokens())
				{
					try
					{
						st = new StringTokenizer(br.readLine());
					}
					catch (IOException e) 
					{
						throw(new RuntimeException());
					}
				}
				return st.nextToken();
			}
			catch(Exception e)
			{
				System.exit(0);
				return "";
			}
		}
		
		public int nextInt()
		{
			return Integer.parseInt(next());
		}
	}
	
	static final double[][] posiciones = new double[18][2];
	static final double[][] distancia = new double[18][18];
	static final double[][] dp = new double[1 << 18][18];
	static double w;
	static double l;
	static int botellas;
	
	public static double mejorDistancia(int a, int b)
	{
		double x1 = posiciones[a][0];
		double y1 = posiciones[a][1];
		double x2 = posiciones[b][0];
		double y2 = posiciones[b][1];
		double mejorDistancia = Double.MAX_VALUE;
		mejorDistancia = Math.min(mejorDistancia, funcionAuxiliar(x1, y1, x2, y2));
		mejorDistancia = Math.min(mejorDistancia, funcionAuxiliar(y1, x1, y2, x2));
		mejorDistancia = Math.min(mejorDistancia, funcionAuxiliar(x1, l - y1, x2, l - y2));
		mejorDistancia = Math.min(mejorDistancia, funcionAuxiliar(y1, w - x1, y2, w - x2));
		return mejorDistancia;
	}
	
	public static double funcionAuxiliar(double x1, double y1, double x2, double y2)
	{
		double x = (x2 - x1) / (2 + ((y2 - y1) / y1));
		double nx = x1 + x;
		double ny = 0;
		return euclidiana(x1, y1, nx, ny) + euclidiana(nx, ny, x2, y2);
	}
	
	public static double euclidiana(double x1, double y1, double x2, double y2)
	{
		return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
	}
	
	public static double dp(int mascara, int posicion)
	{
		if(dp[mascara][posicion] != Double.MAX_VALUE)
			return dp[mascara][posicion];
		if(Integer.bitCount(mascara) == botellas)
		{
			double x = posiciones[posicion][0];
			double y = posiciones[posicion][1];
			double mejor = Double.MAX_VALUE;
			mejor = Math.min(mejor, Math.abs(x));
			mejor = Math.min(mejor, Math.abs(y));
			mejor = Math.min(mejor, Math.abs(w - x));
			mejor = Math.min(mejor, Math.abs(l - y));
			return dp[mascara][posicion] = mejor;
		}
		else
		{
			int mascaraT = mascara;
			double mejor = Double.MAX_VALUE;
			for(int i = 0; i < botellas; i++)
			{
				if((mascaraT & 1) == 0)
				{
					double siguiente = distancia[posicion][i] + dp(mascara | (1 << i), i);
					if(siguiente < mejor)
						mejor = siguiente;
				}
				mascaraT >>= 1;
			}
			return dp[mascara][posicion] = mejor;
		}
	}
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner();
		while(true)
		{
			w = sc.nextInt();
			l = sc.nextInt();
			botellas = sc.nextInt();
			for(int i = 0; i < botellas; i++)
			{
				posiciones[i][0] = sc.nextInt();
				posiciones[i][1] = sc.nextInt();
			}
			for(int i = 0; i < botellas; i++)
				for(int j = 0; j < botellas; j++)
					if(i != j)
						distancia[i][j] = mejorDistancia(i, j);
			final int bot2 = 1 << botellas;
			for(int i = 0; i < bot2; i++)
				for(int j = 0; j < botellas; j++)
					dp[i][j] = Double.MAX_VALUE;
			double mejor = Double.MAX_VALUE;
			double robotX = sc.nextInt();
			double robotY = sc.nextInt();
			for(int i = 0; i < botellas; i++)
			{
				double x = posiciones[i][0];
				double y = posiciones[i][1];
				double distancia = euclidiana(robotX, robotY, x, y);
				mejor = Math.min(mejor, distancia + dp(1 << i, i));
			}
			System.out.println(mejor);
		}
	}
}
