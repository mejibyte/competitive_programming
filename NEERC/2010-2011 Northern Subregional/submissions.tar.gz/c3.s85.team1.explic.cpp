#include <iostream>
#include <cstdio>
#include <set>

using namespace std;

int main(){
    int x = 0, tmp;
    for(int i=0;i<10;++i){ cin >> tmp; x+=tmp;}
    if(x & 1) puts("1");
    else puts("0");
    return 0;
}
