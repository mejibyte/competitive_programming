#include <iostream>
#include <cstdlib>
#include <cstdio>

using namespace std;

int n;

int* f;
int* g;

void print () {
	for (int i = 1; i <= n; ++i)
		cout<<g[i]<<" ";
	cout<<endl;
}

bool check () {
	//puts("check");
	for (int i = 1; i <= n; ++i) {
		if (f[g[i]]!=g[f[i]]){
		//	 puts("end_check");
			return false;
		}
	}
	//puts("end_check");
	return true;
}

void sum () {
	//puts("sum");
	g[n]++;
	int i = n;
	while(g[i]>n) {
		g[i] = 1;
		g[--i]++;
	}
	//print();
	//getchar();
	//puts("endsum");
}

int main () {
	while(cin>>n) {
		f = (int*)malloc((n+3)*sizeof(int));
		g = (int*)malloc((n+3)*sizeof(int));
		for (int i = 1; i <= n; ++i) {
			cin>>f[i];
		}
		f[0]=0;
		for (int i = 0; i <= n; ++i) {
			g[i]=1;
		}
		
		while(!check()) {
			sum();
		}
		puts("ce_finite");
		print();
	}
}
