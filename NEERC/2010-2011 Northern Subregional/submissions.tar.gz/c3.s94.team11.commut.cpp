#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstdio>
#include <cstring>

using namespace std;

int n;

int* f;
int* g;

void print () {
	for (int i = 1; i <= n; ++i)
		cout<<g[i]<<" ";
	cout<<endl;
}

bool check () {
	//puts("check");
	for (int i = 1; i <= n; ++i) {
		if (f[g[i]]!=g[f[i]]){
		//	 puts("end_check");
			return false;
		}
	}
	//puts("end_check");
	return true;
}

void sum () {
	//puts("sum");
	g[n]++;
	int i = n;
	while(g[i]>n) {
		g[i] = 1;
		g[--i]++;
	}
	//print();
	//getchar();
	//puts("endsum");
}

vector <int> check_cycle (int i) {
	bool visited [n+5];
	vector <int> v;
	memset(visited,0,sizeof (visited));
	while(!visited[i]) {
		visited[i]=true;
		v.push_back(i);
		i = f[i];
	}
	return v;
}

int main () {
	while(cin>>n) {
		f = (int*)malloc((n+3)*sizeof(int));
		g = (int*)malloc((n+3)*sizeof(int));
		for (int i = 1; i <= n; ++i) {
			cin>>f[i];
		}
		f[0]=0;
		/*for (int i = 0; i <= n; ++i) {
			g[i]=1;
		}
		
		while(!check()) {
			sum();
		}
		puts("OBVIOUS");
		print();
		puts("----");*/
		for (int i = 0; i <= n; ++i) {
			g[i]=-1;
		}
		int min  = 1<<30;
		for (int i = 1; i <= n; ++i) {
			if(g[i]==-1){
				vector <int> v = check_cycle(i);
				if ((int)v.size()>1) {
					/*cout<<"Pertenecen al ciclo: ";
					for (int j = 0; j < (int)v.size(); ++j) {
						cout<<v[j]<<" ";
					}
					cout<<endl;
					cout<<"comparo entre : "<<f[v[1]]<<" "<<f[v.back()]<<endl;
					*/
					if (f[v[1]] < f[v.back()]) {
						int aux = f[v[0]];
						for (int j = 0; (j+1)<(int)v.size(); ++j) {
							g[v[j]]=f[v[j+1]];
						}
						g[v.back()]=aux;
					}
					else {
						int aux = f[v.back()];
						for (int j = (int)v.size()-1; j-1 >= 0; --j) {
							g[v[j]]=f[v[j-1]];
						}
						g[v[0]]=aux;
					}
				}
				else {
					if (min == 1<<30)
						min = i;
					g[i]=min;
				}
			}
		}
		print();
	}
}
