#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;

int main () {
	int w,h,n;
	while(cin>>w>>h>>n && w) {
		int V[h+3];
		int H[w+3];
//		memset(V,0,sizeof V);
//		memset (H,0,sizeof H);
		for (int i = 0; i < w+3; ++i)
		H[i]=0;
		for (int i = 0; i < h+3; ++i)
		V[i]=0;
		int a,b;
		for (int i = 0; i < n; ++i) {
			cin>>a>>b;
			H[a] = 1;
			V[b] = 1;
		}
		H[w+1]=1;
		V[h+1]=1;
		a = b = 0;
		int prev = 0;
		for (int i = 1; i <= w+1; ++i) {
			if (H[i]) {
				a = max(a,i-prev-1);
				prev = i;
			}
		} 
		prev = 0;
		for (int i = 1; i <= h+1; ++i) {
			if (V[i]) {
				b = max(b,i-prev-1);
				prev = i;
			}
		}
		cout<<a*b<<endl;
	}
}
