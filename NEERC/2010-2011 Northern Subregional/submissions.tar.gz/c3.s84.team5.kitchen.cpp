	#include <cmath>
	#include <cstdio>
	#include <algorithm>

	using namespace std;
	
    double posiciones[18][2];
	double distancia[18][18];
	double dp1[1 << 18][18];
	double maximoValor = 1000000000;
	double w;
	double l;
	int botellas;
	
	double euclidiana(double x1, double y1, double x2, double y2)
	{
		return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
	}
	
	double funcionAuxiliar(double x1, double y1, double x2, double y2)
	{
		double x = (x2 - x1) / (2 + ((y2 - y1) / y1));
		double nx = x1 + x;
		double ny = 0;
		return euclidiana(x1, y1, nx, ny) + euclidiana(nx, ny, x2, y2);
	}
	
	double mejorDistancia(int a, int b)
	{
		double x1 = posiciones[a][0];
		double y1 = posiciones[a][1];
		double x2 = posiciones[b][0];
		double y2 = posiciones[b][1];
		double mejorDistancia = maximoValor;
		mejorDistancia = min(mejorDistancia, funcionAuxiliar(x1, y1, x2, y2));
		mejorDistancia = min(mejorDistancia, funcionAuxiliar(y1, x1, y2, x2));
		mejorDistancia = min(mejorDistancia, funcionAuxiliar(x1, l - y1, x2, l - y2));
		mejorDistancia = min(mejorDistancia, funcionAuxiliar(y1, w - x1, y2, w - x2));
		return mejorDistancia;
	}
	
	double dp(int mascara, int posicion)
	{
		if(dp1[mascara][posicion] != maximoValor)
			return dp1[mascara][posicion];
			int mascaraT = mascara;
			double mejor = maximoValor;
			for(int i = 0; i < botellas; i++)
			{
				if((mascaraT & 1) == 0)
				{
					double siguiente = distancia[posicion][i] + dp(mascara | (1 << i), i);
					if(siguiente < mejor)
						mejor = siguiente;
				}
				mascaraT >>= 1;
			}
			if(mejor == maximoValor)
			{
				double x = posiciones[posicion][0];
				double y = posiciones[posicion][1];
				double mejor = maximoValor;
				mejor = min(mejor, x);
				mejor = min(mejor, y);
				mejor = min(mejor, w - x);
				mejor = min(mejor, l - y);
				return dp1[mascara][posicion] = mejor;
			}
			return dp1[mascara][posicion] = mejor;
	}
	
	int main()
	{
		while(scanf("%lf %lf", &w, &l) != 0)
		{
            if(w == 0)
               break;
			scanf("%d", &botellas);
			for(int i = 0; i < botellas; i++)
			{
				scanf("%lf", &posiciones[i][0]);
				scanf("%lf", &posiciones[i][1]);
			}
			for(int i = 0; i < botellas; i++)
				for(int j = 0; j < botellas; j++)
					if(i != j)
						distancia[i][j] = mejorDistancia(i, j);
			int bot2 = 1 << botellas;
			for(int i = 0; i < bot2; i++)
				for(int j = 0; j < botellas; j++)
					dp1[i][j] = maximoValor;
			double mejor = maximoValor;
			double robotX;
			double robotY;
			scanf("%lf %lf", &robotX, &robotY);
			for(int i = 0; i < botellas; i++)
			{
				double x = posiciones[i][0];
				double y = posiciones[i][1];
				double distancia = euclidiana(robotX, robotY, x, y);
				mejor = min(mejor, distancia + dp(1 << i, i));
			}
			printf("%.6lf\n", mejor);
			return 0;
		}
		return 0;
	}
