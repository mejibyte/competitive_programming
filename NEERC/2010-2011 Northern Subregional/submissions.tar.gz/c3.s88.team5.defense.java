import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;


public class d
{
	public static class Scanner
	{
		final BufferedReader br;
		StringTokenizer st;
		
		public Scanner()
		{
			br = new BufferedReader(new InputStreamReader(System.in));
		}
		
		public String next()
		{
			try
			{
				while(st == null || !st.hasMoreTokens())
				{
					try
					{
						st = new StringTokenizer(br.readLine());
					}
					catch (IOException e) 
					{
						throw(new RuntimeException());
					}
				}
				return st.nextToken();
			}
			catch(Exception e)
			{
				System.exit(0);
				return "";
			}
		}
		
		public int nextInt()
		{
			return Integer.parseInt(next());
		}
	}
	
	static class Torre
	{
		int x;
		int y;
		
		public Torre(int x, int y)
		{
			this.x = x;
			this.y = y;
		}
		
		
	}
	
	static Torre[] torres = new Torre[40002];
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner();
		while(true)
		{
			int alto = sc.nextInt();
			if(alto == 0)
				return;
			int ancho = sc.nextInt();
			int ntorres = sc.nextInt();
			for(int i = 0; i < ntorres; i++)
				torres[i] = new Torre(sc.nextInt(), sc.nextInt());
			torres[ntorres++] = new Torre(0, 0);
			torres[ntorres++] = new Torre(alto + 1, ancho + 1);
		    Arrays.sort(torres, 0, ntorres, new ComparadorX());
		    int distanciaMaxX = 1;
		    for(int i = 0; i < ntorres - 1; i++)
		    	distanciaMaxX = Math.max(distanciaMaxX, torres[i + 1].x - torres[i].x);
		    distanciaMaxX--;
		    Arrays.sort(torres, 0, ntorres, new ComparadorY());
		    int distanciaMaxY = 1;
		    for(int i = 0; i < ntorres - 1; i++)
		    	distanciaMaxY = Math.max(distanciaMaxY, torres[i + 1].y - torres[i].y);
		    distanciaMaxY--;
		    System.out.println(distanciaMaxX * distanciaMaxY);
		}
	}

	static class ComparadorX implements Comparator <Torre>
	{
		@Override
		public int compare(Torre o1, Torre o2)
		{
			return o1.x - o2.x;
		}
	}
	
	static class ComparadorY implements Comparator <Torre>
	{
		@Override
		public int compare(Torre o1, Torre o2)
		{
			return o1.y - o2.y;
		}
	}
}
