
//
// File:    hello.java
// Purpose: prints hello world
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
// Oct 13 1998
//
// $Id: hello.java,v 1.3 1999/10/20 04:51:23 laned Exp $
//

public class hello {
    public static void main(String[] args) 
    {
         System.out.println("Hello World.");
    }
}

// eof
