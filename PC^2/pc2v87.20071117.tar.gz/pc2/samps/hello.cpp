
//
// File:    hello.cpp
// Purpose: prints hello world
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
//
// $Id: hello.cpp,v 1.3 1999/10/20 04:51:23 laned Exp $
//

#include <iostream.h>

main()
{
	cout << "hello world\n";
}

// eof 
